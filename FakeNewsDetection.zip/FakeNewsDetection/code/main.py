import csv
import json
import logging
import time
from neo4j import GraphDatabase
from util.util import Config, News
import tensorflow.compat.v1 as tf

from news_content_collection import NewsContentCollector
from retweet_collection import RetweetCollector
from tweet_collection import TweetCollector
from user_profile_collection import UserProfileCollector, UserTimelineTweetsCollector, UserFollowingCollector, \
    UserFollowersCollector

import json
import re, string
import os
from py2neo import Graph

from gensim.models.doc2vec import Doc2Vec, TaggedDocument
from nltk.tokenize import word_tokenize

import pandas as pd
import pandas as pd
import numpy as np
import nltk
from nltk.corpus import stopwords
from nltk.stem import SnowballStemmer
from _overlapped import NULL


class DataCollectorFactory:

    def __init__(self, config):
        self.config = config

    def get_collector_object(self, feature_type):

        if feature_type == "news_articles":
            return NewsContentCollector(self.config)
        elif feature_type == "tweets":
            return TweetCollector(self.config)
        elif feature_type == "retweets":
            return RetweetCollector(self.config)
        elif feature_type == "user_profile":
            return UserProfileCollector(self.config)
        elif feature_type == "user_timeline_tweets":
            return UserTimelineTweetsCollector(self.config)
        elif feature_type == "user_following":
            return UserFollowingCollector(self.config)
        elif feature_type == "user_followers":
            return UserFollowersCollector(self.config)


def init_config():
    json_object = json.load(open("config.json"))

    config = Config(json_object["dataset_dir"], json_object["dump_location"], json_object["tweet_keys_file"],
                    int(json_object["num_process"]))

    data_choices = json_object["data_collection_choice"]
    data_features_to_collect = json_object["data_features_to_collect"]

    return config, data_choices, data_features_to_collect

def init_logging(config):
    format = '%(asctime)s %(process)d %(module)s %(levelname)s %(message)s'
    # format = '%(message)s'
    logging.basicConfig(
        filename='data_collection_{}.log'.format(str(int(time.time()))),
        level=logging.INFO,
        format=format)
    logging.getLogger('requests').setLevel(logging.CRITICAL)


def download_dataset():
    config, data_choices, data_features_to_collect = init_config()
    init_logging(config)
    data_collector_factory = DataCollectorFactory(config)

    for feature_type in data_features_to_collect:
        data_collector = data_collector_factory.get_collector_object(feature_type)
        data_collector.collect_data(data_choices)
        
def get_neo4j_conn(query1):
   graphdb= GraphDatabase.driver(uri ="bolt://localhost:7687/db/data",auth=("neo4j","12345"))
   session=graphdb.session()
   query="MATCH (n) RETURN n;"
   #nodes=session.run(query)
   nodes=session.run(query1)
   for node in nodes:
     print(node)
  
class Fact(object):
    """__init__() functions as the class constructor"""
    def __init__(self, title=None,text=None, label=None):
        self.title = title
        self.text = text
        self.label = label
        
class Cosine(object):
    """__init__() functions as the class constructor"""
    def __init__(self, title=None,cosine=None):
        self.title = title
        self.cosine = cosine
        
        
if __name__ == "__main__":
    #download_dataset()
    #---Tensor test
    tf.disable_v2_behavior()
    a=tf.constant(7)
    b=tf.constant(10)
    c = tf.add(a,b)
    print(c)    
    simple_session = tf.Session()
    value_of_c = simple_session.run(c)
    print(value_of_c)   # 17
    simple_session.close()
    #----TT Ends--------
    #get_neo4j_conn()
    
    
    #----------FROM UTIL
    
    print("Hello world")
    
factList = []
inut_file = open("C:/MY_STUFF/DBMS_DESIGN/politifact15631/news_content.json").read()
input_json = json.loads(inut_file)
#print(input_json["text"])
title=input_json["title"]
#title=title.replace(",", "")
title="\'"+title+"\'"
desc=input_json["text"]
#desc=desc.replace("\n","")
desc="\'"+desc+"\'"
label="0"
label="\'"+label+"\'"
#print(desc)
query="CREATE (p:fact{name: "+title+",desc: "+desc+",label: "+label+"}) RETURN p"
#print(query)
#query="MATCH (x) return x"
#session.run(query)

#-----------LOAD POLITIFACT FALSE FILES---------------------------------

for root, dirs, files in os.walk("C:\MY_STUFF\DBMS_DESIGN\Brand new\FakeNewsNet-master\code"):
    for name in files:
        if name.endswith(("news content.json")):
            try:
                full_path = os.path.join(root, name)
                if "fake" in full_path and "politifact" in full_path:
                    print("**************************************************************************************")
                    print("LOADING POLITIFACT FALSE NEWS")
                    print("**************************************************************************************")
                    print(full_path)
                    inut_file = open(full_path).read()
                    input_json = json.loads(inut_file)
                    factList.append(Fact(input_json["title"], input_json["text"], "0"))
                    print(input_json["title"])
                
                elif "real" in full_path and "politifact" in full_path:
                    
                    print("**************************************************************************************")
                    print("LOADING POLITIFACT TRUE NEWS")
                    print("**************************************************************************************")
                    print(full_path)
                    inut_file = open(full_path).read()
                    input_json = json.loads(inut_file)
                    factList.append(Fact(input_json["title"], input_json["text"], "1"))
                    print(input_json["title"])
                    
                elif "fake" in full_path and "gossipcop" in full_path:
                    
                    print("**************************************************************************************")
                    print("LOADING GOSSIPCOP FALSE NEWS")
                    print("**************************************************************************************")
                    print(full_path)
                    inut_file = open(full_path).read()
                    input_json = json.loads(inut_file)
                    factList.append(Fact(input_json["title"], input_json["text"], "0"))
                    print(input_json["title"])
                
                elif "real" in full_path and "gossipcop" in full_path:
                    
                    print("**************************************************************************************")
                    print("LOADING GOSSIPCOP TRUE NEWS")
                    print("**************************************************************************************")
                    print(full_path)
                    inut_file = open(full_path).read()
                    input_json = json.loads(inut_file)
                    factList.append(Fact(input_json["title"], input_json["text"], "1"))
                    print(input_json["title"])
            except:
                continue
            
#-----------LOAD POLITIFACT FALSE FILES---------------------------------

print("************checking************")
print(factList[0].title)
input_query="DNC Server Was Not Hacked By Russia"
cosineList=[]
sent=""
j=0
cos=[]
for fact in  factList:
 try:
    X = input_query
    Y =fact.title
    print("INPUT SENT:")
    print(X)
    
    print("FACT SENT:")
    print(Y)
    if Y is not None and Y is not "":
        # tokenization 
        X_list = word_tokenize(X)  
        Y_list = word_tokenize(Y) 
    
        # sw contains the list of stopwords 
        sw = stopwords.words('english')  
        l1 =[];l2 =[] 
    
        # remove stop words from string 
        X_set = {w for w in X_list if not w in sw}  
        Y_set = {w for w in Y_list if not w in sw}
    
        # form a set containing keywords of both strings  
        rvector = X_set.union(Y_set)  
        for w in rvector: 
            if w in X_set: l1.append(1) # create a vector 
            else: l1.append(0) 
            if w in Y_set: l2.append(1) 
            else: l2.append(0) 
            c = 0
        print("VECTOR FOR INPUT:")
        print(l1)
        print("VECTOR FOR FACT:")
        print(l2)
        # cosine formula  
        for i in range(len(rvector)): 
            c+= l1[i]*l2[i] 
            cosine = c / float((sum(l1)*sum(l2))**0.5)
        
        #cosineList.append(i,cosine*100)     
        print("similarity%: ", cosine*100)
    
        cosineList.append(Cosine(fact.title, cosine*100))
 except:
    continue
print("#######################DONE COSINE##################")  
for i in cosineList:
    temp=i.cosine
    cos.append(temp)
    #cos[j]=temp
    #j=j+1
cos.sort(key=None, reverse=True)
    
maxcos=cos[0]
print("**********MAX SIMILARITY FACT FOUND****************")
print(maxcos)

if maxcos <20.0:
    print("Fact Unknown for this input")
for i in cosineList:
    if(i.cosine==maxcos):
        sent=i.title
        print("******TITLE*************")
        print(sent)
for i in factList:
    if(i.title==sent):
        label=i.label
        print("****************LABEL************")
        print(label)
 
#print("The fact label is "+label+"for "+sent)          


        
    