package com;

import java.awt.Frame;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;

import org.deeplearning4j.nn.conf.MultiLayerConfiguration;
import org.deeplearning4j.nn.conf.NeuralNetConfiguration;
import org.deeplearning4j.nn.conf.Updater;
import org.deeplearning4j.nn.conf.inputs.InputType;
import org.deeplearning4j.nn.conf.layers.ConvolutionLayer;
import org.deeplearning4j.nn.conf.layers.OutputLayer;
import org.deeplearning4j.nn.conf.layers.SubsamplingLayer;
import org.deeplearning4j.nn.multilayer.MultiLayerNetwork;
import org.deeplearning4j.nn.weights.WeightInit;
import org.nd4j.linalg.activations.Activation;
import org.nd4j.linalg.lossfunctions.LossFunctions;
import org.deeplearning4j.nn.*;
import org.deeplearning4j.nn.api.OptimizationAlgorithm;

import util.Util;

public class main {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		String inputFileClear="C:\\MY_STUFF\\SE\\Assignment3-Programming\\Noise2Self\\src\\main\\java\\Images\\noisy5.jpg";
		//String inputFileClear="C:\\MY_STUFF\\SE\\Assignment3-Programming\\Noise2Self\\src\\main\\java\\Images\\clear.jpg";
		
		
		String inputFileGausianNoisy="C:\\MY_STUFF\\SE\\Assignment3-Programming\\Noise2Self\\src\\main\\java\\Images\\Noisy1.jpg";
		String outputFileGausianNoisy="C:\\MY_STUFF\\SE\\Assignment3-Programming\\Noise2Self\\src\\main\\java\\Images\\Gaus_Noise1.jpg";
		
		
		String inputFileInterpolate="C:\\MY_STUFF\\SE\\Assignment3-Programming\\Noise2Self\\src\\main\\java\\Images\\Interpolated1.jpg";
		String outputFileInterpolate="C:\\MY_STUFF\\SE\\Assignment3-Programming\\Noise2Self\\src\\main\\java\\Images\\Interpolated1.jpg";
		
		String inputFileMedian="C:\\MY_STUFF\\SE\\Assignment3-Programming\\Noise2Self\\src\\main\\java\\Images\\Median1.jpg";
		String outputFileMedian="C:\\MY_STUFF\\SE\\Assignment3-Programming\\Noise2Self\\src\\main\\java\\Images\\Median1.jpg";
				
		
		String inputFileDon="C:\\MY_STUFF\\SE\\Assignment3-Programming\\Noise2Self\\src\\main\\java\\Images\\Donut_Filter.jpg";
		String outputFileDon="C:\\MY_STUFF\\SE\\Assignment3-Programming\\Noise2Self\\src\\main\\java\\Images\\Donut_Filter1.png";
		String outputFileDonMean="C:\\MY_STUFF\\SE\\Assignment3-Programming\\Noise2Self\\src\\main\\java\\Images\\Donut_Filter_Mean1.jpg";
		
		
		BufferedImage inputClear = null;
		BufferedImage inputGausianNoisy = null;
		BufferedImage inputInterpolate = null;
		BufferedImage inputMedian = null;
		BufferedImage inputDon = null;
		
		
		BufferedImage outputClear = null;
		BufferedImage outputGausianNoisy = null;
		BufferedImage outputInterpolate = null;
		BufferedImage outputMedian = null;
		BufferedImage outputDon = null;
		BufferedImage outputDonMean = null;
		
		
	
		
		try {
			
			BufferedImage input = ImageIO.read(new File("C:\\MY_STUFF\\SE\\Assignment3-Programming\\Noise2Self\\src\\main\\java\\Images\\noisy_10.jpg"));
			//inputClear = ImageIO.read(new File(inputFileClear));
			//inputGausianNoisy = ImageIO.read(new File(inputFileGausianNoisy));
			//inputInterpolate = ImageIO.read(new File(inputFileInterpolate));
			//inputMedian = ImageIO.read(new File(inputFileMedian));
			//inputDon = ImageIO.read(new File(inputFileDon));
			
			//outputGausianNoisy=Util.gaussianNoise(input,input, 10);
			//Util.saveImage(outputGausianNoisy, "jpg", outputFileGausianNoisy);
		
			outputMedian=Util.medianFilter(input);
			Util.saveImage(outputMedian, "jpg", outputFileMedian);
			
			System.out.println("Saved Median");
			input = ImageIO.read(new File("C:\\MY_STUFF\\SE\\Assignment3-Programming\\Noise2Self\\src\\main\\java\\Images\\noisy_10.jpg"));
			outputInterpolate=Util.Interpolate(input);
			Util.saveImage(outputInterpolate, "jpg", outputFileInterpolate);
			System.out.println("Saved Interpolated");
			
			input = ImageIO.read(new File("C:\\MY_STUFF\\SE\\Assignment3-Programming\\Noise2Self\\src\\main\\java\\Images\\noisy_10.jpg"));
			outputDon=Util.donutFilter(input);
			Util.saveImage(outputDon, "jpg", outputFileDon);
			System.out.println("Saved Donut");
			
			
			input = ImageIO.read(new File("C:\\MY_STUFF\\SE\\Assignment3-Programming\\Noise2Self\\src\\main\\java\\Images\\noisy_10.jpg"));
			outputDonMean=Util.donutFilterMean(input);
			Util.saveImage(outputDon, "jpg", outputFileDonMean);
			System.out.println("Saved Donut");
			//Util.imageAnalysis(inputGausianNoisy,inputInterpolate);
			
			//input = ImageIO.read(new File("C:\\MY_STUFF\\SE\\Assignment3-Programming\\Noise2Self\\src\\main\\java\\Images\\clear1.jpg"));
			//BufferedImage input1 = ImageIO.read(new File("C:\\MY_STUFF\\SE\\Assignment3-Programming\\Noise2Self\\src\\main\\java\\Images\\var1.jpg"));
			
			//double mse=Util.mse(input1);
			//System.out.println(mse); 
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		//JFrame f = new Util();
	    //f.setTitle("ConvolveIt");
	    //f.setSize(300, 250);
	    //f.setSize(500, 500);
	   
	    //BufferedImage outImage1 = new BufferedImage(f.getWidth(),f.getHeight(),BufferedImage.TYPE_INT_RGB);
	    //Graphics2D graphics2D = outImage1.createGraphics();
        //f.paint(graphics2D);
	    //f.show();
	    /*try {
	    	f.setVisible(true);
			ImageIO.write(outImage1, "jpg", new File(outputFile1));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}*/
		
		/*ONLY MEDIAN FILTER ON INPUT
		outImageMed=Util.medianFilter(input);
		try {
			ImageIO.write(outImageMed, "jpg", new File(outputFileMed));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		//outImageDon=Util.Interpolate(input);
		//Util.addGaussian(1, 1, inputClear);
		
		//Util.getPixel(inputClear);
		//outImageGaus=Util.removeGausian(inputClear);
		//outImageDon=Util.medianFilter(outImageDon);
		//outImageDon=Util.Interpolate(outImageDon);
		/*
		
		//Adding Gaussian Noise to a clear Image
		outputGausianNoisy=Util.addGausian(inputClear);
		Util.saveImage(outputGausianNoisy, "jpg", outputFileGausianNoisy);
		
		//Applying Median Filter to Gausian Noisy Image
		outputMedian=Util.medianFilter(outputGausianNoisy);
		Util.saveImage(outputMedian, "jpg", outputFileMedian);*/
		
		
		/*//Applying Donut Filter to Gausian Noisy Image
		outputDon=Util.donutFilter(inputClear);
		Util.saveImage(outputDon, "jpg", outputFileDon);*/
		
		/*//Applying Interpolation Filter to Gausian Noisy Image
		outputInterpolate=Util.Interpolate(inputClear);
		Util.saveImage(outputInterpolate, "jpg", outputFileInterpolate);*/
		
		/*outputMedian=Util.medianFilter(inputClear);
		Util.saveImage(outputMedian, "jpg", outputFileMedian);*/
		
		/*outImageDon=Util.donutFilter(outImageDon);
		outImageDon=Util.donutFilter(outImageDon);
		outImageDon=Util.donutFilter(outImageDon);
		outImageDon=Util.donutFilter(outImageDon);
		outImageDon=Util.donutFilter(outImageDon);
		outImageDon=Util.donutFilter(outImageDon);
		outImageDon=Util.donutFilter(outImageDon);*/
		
				
		/*//**********************VERY VERY IMP************************
		outImage1=Util.Interpolate(input);
		try {
			ImageIO.write(outImage1, "jpg", new File(outputFile1));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    outImage2=Util.denoise_wavelet(outImage1);
	    try {
			ImageIO.write(outImage2, "jpg", new File(outputFile2));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
	    outImage3=Util.medianFilter(outImage2);
	    try {
			ImageIO.write(outImage3, "jpg", new File(outputFile3));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    /*JPanel panel = new JPanel();
	    f.add(panel);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.pack();
        f.setVisible(true);*/
	  //**********************VERY VERY IMP************************ */
		
	/*	ConvolutionLayer layer0 = new ConvolutionLayer.Builder(5,5)
		        .nIn(3)
		        .nOut(16)
		        .stride(1,1)
		        .padding(2,2)
		        .weightInit(WeightInit.XAVIER)
		        .name("First convolution layer")
		        .activation(Activation.RELU)
		        .build();

		SubsamplingLayer layer1 = new SubsamplingLayer.Builder(SubsamplingLayer.PoolingType.MAX)
		        .kernelSize(2,2)
		        .stride(2,2)
		        .name("First subsampling layer")
		        .build();

		ConvolutionLayer layer2 = new ConvolutionLayer.Builder(5,5)
		        .nOut(20)
		        .stride(1,1)
		        .padding(2,2)
		        .weightInit(WeightInit.XAVIER)
		        .name("Second convolution layer")
		        .activation(Activation.RELU)
		        .build();

		SubsamplingLayer layer3 = new SubsamplingLayer.Builder(SubsamplingLayer.PoolingType.MAX)
		        .kernelSize(2,2)
		        .stride(2,2)
		        .name("Second subsampling layer")
		        .build();

		ConvolutionLayer layer4 = new ConvolutionLayer.Builder(5,5)
		        .nOut(20)
		        .stride(1,1)
		        .padding(2,2)
		        .weightInit(WeightInit.XAVIER)
		        .name("Third convolution layer")
		        .activation(Activation.RELU)
		        .build();

		SubsamplingLayer layer5 = new SubsamplingLayer.Builder(SubsamplingLayer.PoolingType.MAX)
		        .kernelSize(2,2)
		        .stride(2,2)
		        .name("Third subsampling layer")
		        .build();

		OutputLayer layer6 = new OutputLayer.Builder(LossFunctions.LossFunction.NEGATIVELOGLIKELIHOOD)
		        .activation(Activation.SOFTMAX)
		        .weightInit(WeightInit.XAVIER)
		        .name("Output")
		        .nOut(10)
		        .build();
		MultiLayerConfiguration configuration = new NeuralNetConfiguration.Builder()
		        .seed(12345)
		        .iterations(1)
		        .optimizationAlgo(OptimizationAlgorithm.STOCHASTIC_GRADIENT_DESCENT)
		        .learningRate(0.001)
		        .regularization(true)
		        .l2(0.0004)
		        .updater(Updater.NESTEROVS)
		        .momentum(0.9)
		        .list()
		            .layer(0, layer0)
		            .layer(1, layer1)
		            .layer(2, layer2)
		            .layer(3, layer3)
		            .layer(4, layer4)
		            .layer(5, layer5)
		            .layer(6, layer6)
		        .pretrain(false)
		        .backprop(true)
		        .setInputType(InputType.convolutional(32,32,3))
		        .build();
		
		MultiLayerNetwork network = new MultiLayerNetwork(configuration);
		network.init();
		
		//Training the model
		//network.fit(dataSetIterator);
		
		//Evaluation
		//Evaluation evaluation = network.evaluate(new CifarDataSetIterator(2, 500, false));
		//System.out.println(evaluation.stats());*/
	}

}
