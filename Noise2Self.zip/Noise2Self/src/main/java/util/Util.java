package util;

import java.awt.Color;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.awt.image.BufferedImageOp;
import java.awt.image.ConvolveOp;
import java.awt.image.Kernel;
import java.awt.image.Raster;
import java.awt.image.WritableRaster;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Random;
import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.factory.Nd4j;
import org.tensorflow.Tensor;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;





public class Util extends JFrame{
	Image image = getImage("C:\\\\\\\\MY_STUFF\\\\\\\\SE\\\\\\\\Assignment3-Programming\\\\\\\\ImageDenoising\\\\\\\\src\\\\\\\\main\\\\\\\\java\\\\\\\\com\\\\\\\\noisy4.jpg");
	private double mean=0;
	private double sigma=30;
	
	 /* private static final float[] SHARP = { 0.0f, -1.0f, 0.0f, -1.0f, 5.0f,
	      -1.0f, 0.0f, -1.0f, 0.0f };*/
	 
	  public double getMean() {
		return mean;
	}

	public void setMean(double mean) {
		this.mean = mean;
	}

	public double getSigma() {
		return sigma;
	}

	public void setSigma(double sigma) {
		this.sigma = sigma;
	}

	//donut filter
	 private static final float[] SHARP = { 0, 0.25f, 0, 0.25f, 0,
		      0.25f,0, 0.25f, 0 };
	 
	 
	  
	  /*private static final float[] SHARP = { 1, 0, -1, 1,
		      0,-1,1,0,-1};*/

	  BufferedImage bufferedImage;

	  ConvolveOp convolveOp;

	  public Image getImage(String imageFile) {
	    ImageIcon icon = new ImageIcon(imageFile);
	    return icon.getImage();
	  }
	  
	  public Util() {
	    int width = image.getWidth(this);
	    int height = image.getHeight(this);
	    bufferedImage = new BufferedImage(width, height,
	        BufferedImage.TYPE_INT_RGB);
	    Graphics2D big = bufferedImage.createGraphics();
	    
	    AffineTransform affineTransform = new AffineTransform();
	    big.drawImage(image, affineTransform, this);
	    Kernel kernel = new Kernel(3, 3, SHARP);
	    convolveOp = new ConvolveOp(kernel, ConvolveOp.EDGE_NO_OP, null);
	  
	    }

	  public void paint(Graphics g) {
	    Graphics2D g2d = (Graphics2D) g;
	   
	    if (bufferedImage != null) {

	      g2d.drawImage(bufferedImage, convolveOp, 10, 30);
	    }
	  }
	  
	  
	  
	  public BufferedImage  interpolate_image(BufferedImage img) {
		    int width = image.getWidth(this);
		    int height = image.getHeight(this);
		    bufferedImage = new BufferedImage(width, height,
		        BufferedImage.TYPE_INT_RGB);
		    Graphics2D big = bufferedImage.createGraphics();
		    AffineTransform affineTransform = new AffineTransform();
		    big.drawImage(image, affineTransform, this);
		    Kernel kernel = new Kernel(3, 3, SHARP);
		    convolveOp = new ConvolveOp(kernel, ConvolveOp.EDGE_NO_OP, null);
			return img;
		  }
	  
	  public int[][] numpyZeros(int width,int height) {
		  int outputNz[][]=new int[width][height];
		  for(int i=0;i<width;i++) {
			  for(int j=0;j<height;j++) {
				  outputNz[i][j]=0;
			  }
		  }
		return outputNz;
	  }
	  
	  public int[][] generate_mask(int width,int height,int idx) {
		  
		  int m[][]=new int[width][height];
		  int phasex,phasey;
		  m=numpyZeros(width, height);
		  phasex = idx % width;
		  phasey =  Math.floorDiv(idx,width)%width;
		  m[phasex][phasey]=1;
		  return m;
	  }
	 
	  
	  public void invariant_denoise(BufferedImage img, int width, int denoiser) {
		  int n_masks;
		  int m[][]=new int[img.getWidth()][img.getHeight()];
		  BufferedImage interp;
		  int output[][]=new int[img.getWidth()][img.getHeight()];
		  
		  n_masks= width*width;
				    
				    interp = interpolate_image(img);
				    
				    output = numpyZeros(img.getWidth(),img.getHeight());
				    
				    for (int i=0;i<n_masks;i++) {
				    	 m = generate_mask(img.getWidth(), img.getHeight(), i);
				    	 //input_image = m*interp + (1 - m)*img
						 //input_image = input_image.astype(img.dtype)
						 //output += m*denoiser(input_image)
				    }
				       
	  }
	  
	  public static BufferedImage addGausian(BufferedImage input) {
		  
		//Gausian filter
		  BufferedImage output = null,blurredImage;
			 final float[] gausian = {1/16f, 1/8f, 1/16f, 
					    1/8f, 1/4f, 1/8f, 
					    1/16f, 1/8f, 1/16f};
			 BufferedImageOp op = new ConvolveOp( new Kernel(3, 3, gausian) );
			 blurredImage = op.filter(input, output);
			 return blurredImage;
	  }
	  
	
	  public static BufferedImage Interpolate(BufferedImage input) {
		  
			//Interpolate filter
		  BufferedImage output = null,blurredImage;
		  final float[] interpolate = { 0, 0.25f, 0, 0.25f, 0,
			      0.25f,0, 0.25f, 0 };
			 BufferedImageOp op = new ConvolveOp( new Kernel(3, 3, interpolate) );
			 blurredImage = op.filter(input, output);
			 return blurredImage;
			
		  }
	  
	  public static BufferedImage medianFilter(BufferedImage input) {
		//Median filter
		  Color[] pixel=new Color[9];
	        int[] R=new int[9];
	        int[] B=new int[9];
	        int[] G=new int[9];
		  for(int i=1;i<input.getWidth()-1;i++)
	            for(int j=1;j<input.getHeight()-1;j++)
	            {
	               pixel[0]=new Color(input.getRGB(i-1,j-1));
	               pixel[1]=new Color(input.getRGB(i-1,j));
	               pixel[2]=new Color(input.getRGB(i-1,j+1));
	               
	               pixel[3]=new Color(input.getRGB(i,j+1));
	               pixel[4]=new Color(input.getRGB(i+1,j+1));
	               pixel[5]=new Color(input.getRGB(i+1,j));
	               
	               pixel[6]=new Color(input.getRGB(i+1,j-1));
	               pixel[7]=new Color(input.getRGB(i,j-1));
	               pixel[8]=new Color(input.getRGB(i,j));
	               
	               for(int k=0;k<9;k++){
	                   R[k]=pixel[k].getRed();
	                   B[k]=pixel[k].getBlue();
	                   G[k]=pixel[k].getGreen();
	               }
	               Arrays.sort(R);
	               Arrays.sort(G);
	               Arrays.sort(B);
	               input.setRGB(i,j,new Color(R[4],B[4],G[4]).getRGB());
	            }
		return input;
		  
		  }
	  
	  public static BufferedImage donutFilter(BufferedImage input) {
			//Donut filter
			  Color[] pixel=new Color[9];
		        int[] R=new int[9];
		        int[] B=new int[9];
		        int[] G=new int[9];
			  for(int i=1;i<input.getWidth()-1;i++)
		            for(int j=1;j<input.getHeight()-1;j++)
		            {
		               pixel[0]=new Color(input.getRGB(i-1,j-1));
		               pixel[1]=new Color(input.getRGB(i-1,j));
		               pixel[2]=new Color(input.getRGB(i-1,j+1));
		               
		               pixel[3]=new Color(input.getRGB(i,j+1));
		               //pixel[4]=new Color(input.getRGB(i+1,j+1));
		               pixel[4]=new Color(0xff000000);//0xff000000
		               pixel[5]=new Color(input.getRGB(i+1,j));
		               
		               pixel[6]=new Color(input.getRGB(i+1,j-1));
		               pixel[7]=new Color(input.getRGB(i,j-1));
		               pixel[8]=new Color(input.getRGB(i,j));
		               
		               for(int k=0;k<9;k++){
		                   R[k]=pixel[k].getRed();
		                   B[k]=pixel[k].getBlue();
		                   G[k]=pixel[k].getGreen();
		               }
		               Arrays.sort(R);
		               Arrays.sort(G);
		               Arrays.sort(B);
		               //input.setRGB(i,j,new Color(R[4],B[4],G[4]).getRGB());--main
		               input.setRGB(i,j,new Color(R[4],G[4],B[4]).getRGB());
		            }
			return input;
			  
			  }
	  public static BufferedImage donutFilterMean(BufferedImage input) {
			//Donut filter
			  Color[] pixel=new Color[9];
		        int[] R=new int[9];
		        int[] B=new int[9];
		        int[] G=new int[9];
			  for(int i=1;i<input.getWidth()-1;i++)
		            for(int j=1;j<input.getHeight()-1;j++)
		            {
		               pixel[0]=new Color(input.getRGB(i-1,j-1));
		               pixel[1]=new Color(input.getRGB(i-1,j));
		               pixel[2]=new Color(input.getRGB(i-1,j+1));
		               
		               pixel[3]=new Color(input.getRGB(i,j+1));
		               //pixel[4]=new Color(input.getRGB(i+1,j+1));
		               pixel[4]=new Color(0xff000000);//0xff000000
		               pixel[5]=new Color(input.getRGB(i+1,j));
		               
		               pixel[6]=new Color(input.getRGB(i+1,j-1));
		               pixel[7]=new Color(input.getRGB(i,j-1));
		               pixel[8]=new Color(input.getRGB(i,j));
		               
		               for(int k=0;k<9;k++){
		                   R[k]=pixel[k].getRed();
		                   B[k]=pixel[k].getBlue();
		                   G[k]=pixel[k].getGreen();
		               }
		               Arrays.sort(R);
		               Arrays.sort(G);
		               Arrays.sort(B);
		               int r_mean,g_mean,b_mean,sum=0;
		               
		               for(int k:R){
		            	   sum=sum+k;
		               }
		               r_mean=sum/R.length;
		               sum=0;
		               
		               for(int k:R){
		            	   sum=sum+k;
		               }
		               g_mean=sum/R.length;
		               sum=0;
		               
		               for(int k:R){
		            	   sum=sum+k;
		               }
		               b_mean=sum/R.length;
		               sum=0;
		               
		               input.setRGB(i,j,new Color(r_mean,b_mean,g_mean).getRGB());
		            }
			return input;
			  
			  }
	  
	  public static BufferedImage addGaussian(double mean, double variance,BufferedImage input){
		  int gausianNoise=0;
		/*
		 *  gausianNoise= (int) (mean + new Random().nextGaussian() *
		 * variance);
		 */
		  
		  Random rnd = new Random();
		   gausianNoise = (int) ((rnd.nextGaussian() - mean) / Math.sqrt(variance));
		  
		 /* int[][] outPixel= new int[input.getHeight()][input.getWidth()];
		  outPixel= getPixel(input);
				  for (int i = 0; i < input.getHeight(); i++) {
				         for (int j = 0; j < input.getWidth(); j++) {
				        	 Color c = new Color(input.getRGB(j,i));
				        	 int red = c.getRed();
				        	 int green = c.getGreen();
				        	 int blue = c.getBlue();
				        	 
				        	 input.set
				            outPixel[i][j] = input.getRGB(j, i)+ gausianNoise;
				            input.setRGB(j, i, outPixel[i][j]);
				         }
				      }*/
		  int red = 0,blue=0,green=0;
		  System.out.println("Gaussian Noise"+gausianNoise);
		  
		  for (int i = 0; i < input.getHeight(); i++) {
		         for (int j = 0; j < input.getWidth(); j++) {
		        	 
					
		        	 Color c = new Color(input.getRGB(j,i));
		        	  red = (int) c.getRed();
		        	  green =(int) c.getGreen();
		        	  blue = (int) c.getBlue();	 
		        	
		        	 
		        	 System.out.println("Red: "+(c.getRed()+gausianNoise)+"Green :"+c.getGreen()+gausianNoise+"Blue :"+c.getBlue()+gausianNoise);
		        	 if((red+gausianNoise)>255) {
		        		 red=255;
		        	 }else if((c.getRed()+gausianNoise)<0) {
		        		 red=0;
		        	 }else {
		        		 red=c.getRed()+gausianNoise;
		        	 }
		        	 
				/*
				 * if((c.getBlue()+gausianNoise)>255) { blue=255; }else
				 * if((c.getBlue()+gausianNoise)<0){ blue=0; }
				 * 
				 * if((c.getGreen()+gausianNoise)>255) { green=255; }else
				 * if((c.getGreen()+gausianNoise)<0){ green=0; }
				 */
		        	 int c1 =new Color(red, green, blue).getRGB(); 
		        	 input.setRGB(j, i, c1);
		        	
		         }
		  }
		return input;
	}
	  
	  
	  public static int[][] getPixel(BufferedImage input) {
		  int[][] output=new int[input.getHeight()][input.getWidth()];
		  
	      for (int i = 0; i < input.getHeight(); i++) {
	         for (int j = 0; j < input.getWidth(); j++) {
	        	 
	            output[i][j] = input.getRGB(j, i);
	         }
	      }
	      
	      for (int i = 0; i < input.getHeight(); i++) {
		         for (int j = 0; j < input.getWidth(); j++) {
		            System.out.println(output[i][j]);
		         }
		      }

	      return output;
	  }
	  
	  public static int[] getSinglePixel(BufferedImage input) {
		  int[] output=new int[input.getHeight()*input.getWidth()];
		  int rgb,r,g,b;
		  int k=0;
	      for (int i = 0; i < input.getHeight(); i++) {
	         for (int j = 0; j < input.getWidth(); j++) {
	        	  rgb = input.getRGB(j, i);
	        	  r = (rgb >> 16) & 0xFF;
	        	  g = (rgb >> 8) & 0xFF;
	        	  b = (rgb & 0xFF);
	            output[k]= (r + g + b) / 3;
	            System.out.println(output[k]); 
	            k++;
	         }
	      }
	      System.out.println();     

	      return output;
	  }
	  
	  public Tensor convertTensor(BufferedImage input) {
		  int[][] arr = new int[input.getHeight()][input.getWidth()];
		  
		  arr=getPixel(input);
		  Tensor<?> output = Tensor.create(arr);
		  		  
		return output;
		  
	  }
	  
	  public static void saveImage(BufferedImage input,String format,String file) {
		  try {
				ImageIO.write(input, format, new File(file));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	  }
	  
	  public static void imageAnalysis(BufferedImage input1,BufferedImage input2) {
		  	int width1 = input1.getWidth(); 
	        int width2 = input2.getWidth(); 
	        int height1 = input1.getHeight(); 
	        int height2 = input2.getHeight(); 
	        if ((width1 != width2) || (height1 != height2)) {
	        	System.out.println("Error: Images dimensions"+ 
                        " mismatch"); 
	        }	            
	        else
	        { 
	            long difference = 0; 
	            for (int y = 0; y < height1; y++) 
	            { 
	                for (int x = 0; x < width1; x++) 
	                { 	//RGB value of 
	                    int rgb1 = input1.getRGB(x, y); 
	                    int rgb2 = input2.getRGB(x, y); 
	                    
	                    int red1 = (rgb1 >> 16) & 0xff; 
	                    int green1 = (rgb1 >> 8) & 0xff; 
	                    int blue1 = (rgb1) & 0xff; 
	                    
	                    int red2 = (rgb2 >> 16) & 0xff; 
	                    int green2 = (rgb2 >> 8) & 0xff; 
	                    int blue2 = (rgb2) & 0xff; 
	                    
	                    difference =difference+ Math.abs(red1 - red2); 
	                    difference =difference+ Math.abs(green1 - green2); 
	                    difference =difference+ Math.abs(blue1 - blue2); 
	                } 
	            } 
	  
	            // Total number of red pixels = width * height 
	            // Total number of blue pixels = width * height 
	            // Total number of green pixels = width * height 
	            // So total number of pixels = width * height * 3 
	            double total_pixels = width1 * height1 * 3; 
	  
	            // Normalizing the value of different pixels 
	            // for accuracy(average pixels per color 
	            // component) 
	            double avg_different_pixels = difference / 
	                                          total_pixels; 
	            System.out.println("Average Difference"+avg_different_pixels);
	  
	            // There are 255 values of pixels in total 
	            double percentage = (avg_different_pixels / 
	                                            255) * 100; 
	  
	            System.out.println("Difference Percentage-->" + 
	                                                percentage); 
	        } 
	  }
	  
	 /* public static void imageConcat(BufferedImage input1,BufferedImage input2,BufferedImage input3) {
		  int imagesCount = 3;
	        BufferedImage images[] = new BufferedImage[imagesCount];
	        images[0]=input1;
	        images[1]=input2;
	        images[2]=input3;
	        
	        for(int j = 0; j < images.length; j++) {
	            //images[j] = new BufferedImage(100, 100, BufferedImage.TYPE_INT_RGB);
	            Graphics2D g2d = images[j].createGraphics();
	            g2d.drawRect(10, 10, 80, 80);
	            g2d.dispose();
	        }
	        int heightTotal = 0;
	        for(int j = 0; j < images.length; j++) {
	            heightTotal += images[j].getHeight();
	        }
	        
	        int heightCurr = 0;
	        BufferedImage concatImage = new BufferedImage(100, heightTotal, BufferedImage.TYPE_INT_RGB);
	        Graphics2D g2d = concatImage.createGraphics();
	        for(int j = 0; j < images.length; j++) {
	            g2d.drawImage(images[j], 0, heightCurr, null);
	            heightCurr += images[j].getHeight();
	        }
	        g2d.dispose();
	        
	        ImageIO.write(concatImage, "png", new File("/home/jens/concat.png")); // export concat image
	        ImageIO.write(images[0], "png", new File("/home/jens/single.png")); // export single imag
	  }
	  */
	  
	  public static BufferedImage gaussianNoise(BufferedImage image, BufferedImage output,double stdDev) {
	        Raster source = image.getRaster();
	        WritableRaster out = output.getRaster();
	          
	        int currVal;                    // the current value
	        double newVal;                  // the new "noisy" value
	        double gaussian;                // gaussian number
	        int bands  = out.getNumBands(); // number of bands
	        int width  = image.getWidth();  // width of the image
	        int height = image.getHeight(); // height of the image
	        java.util.Random randGen = new java.util.Random();
	          
	        for (int j=0; j<height; j++) {
	            for (int i=0; i<width; i++) {
	                gaussian = randGen.nextGaussian();
	                  
	                for (int b=0; b<bands; b++) {
	                    newVal = stdDev * gaussian;
	                    currVal = source.getSample(i, j, b);
	                    newVal = newVal + currVal;
	                    if (newVal < 0)   newVal = 0.0;
	                    if (newVal > 255) newVal = 255.0;
	                      
	                    out.setSample(i, j, b, (int)(newVal));
	                }
	            }
	        }
	          
	        return output;
	    }
	  
	  public static double mse(BufferedImage input1) {
		  int sum_sq = 0;
		  int sum=0;
		  double mse;
		  int image1[]=getSinglePixel(input1);
		  for(int i:image1) {
			  sum=sum+i;
		  }
		  System.out.println(sum);
		  System.out.println("No of pixels"+(input1.getHeight() * input1.getWidth()));
		  double mean=sum/(input1.getHeight() * input1.getWidth());
		  System.out.println(mean);
		  for(int i=0;i<image1.length;i++) {
			  int p1 = image1[i];
	    
	          double err = mean-p1;
	          sum_sq += (err * err);
		  }
		  mse = (double)sum_sq / (input1.getHeight() * input1.getWidth());
		  return mse;
	  }
	  
}