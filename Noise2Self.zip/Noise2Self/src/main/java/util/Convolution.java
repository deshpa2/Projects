package util;


import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.awt.image.ConvolveOp;
import java.awt.image.Kernel;

import javax.swing.ImageIcon;
import javax.swing.JFrame;

public class Convolution extends JFrame{
	 Image image = getImage("C:\\\\\\\\MY_STUFF\\\\\\\\SE\\\\\\\\Assignment3-Programming\\\\\\\\ImageDenoising\\\\\\\\src\\\\\\\\main\\\\\\\\java\\\\\\\\com\\\\\\\\noisy3.jpg");

	 /* private static final float[] SHARP = { 0.0f, -1.0f, 0.0f, -1.0f, 5.0f,
	      -1.0f, 0.0f, -1.0f, 0.0f };*/
	 
	  //donut filter
	 private static final float[] SHARP = { 0, 0.25f, 0, 0.25f, 0,
		      0.25f,0, 0.25f, 0 };
	  
	  /*private static final float[] SHARP = { 1, 0, -1, 1,
		      0,-1,1,0,-1};*/

	  BufferedImage bufferedImage;

	  ConvolveOp convolveOp;

	  public Image getImage(String imageFile) {
	    ImageIcon icon = new ImageIcon(imageFile);
	    return icon.getImage();
	  }

	  public Convolution() {
	    int width = image.getWidth(this);
	    int height = image.getHeight(this);
	    bufferedImage = new BufferedImage(width, height,
	        BufferedImage.TYPE_INT_RGB);
	    Graphics2D big = bufferedImage.createGraphics();
	    AffineTransform affineTransform = new AffineTransform();
	    big.drawImage(image, affineTransform, this);
	    Kernel kernel = new Kernel(3, 3, SHARP);
	    convolveOp = new ConvolveOp(kernel, ConvolveOp.EDGE_NO_OP, null);
	  }

	  public void paint(Graphics g) {
	    Graphics2D g2d = (Graphics2D) g;
	    if (bufferedImage != null) {
	      g2d.drawImage(bufferedImage, convolveOp, 10, 30);
	    }
	  }
	  
	  public int[][] numpyZeros(int width,int height) {
		  int outputNz[][]=new int[width][height];
		  for(int i=0;i<width;i++) {
			  for(int j=0;j<height;j++) {
				  outputNz[i][j]=0;
			  }
		  }
		return outputNz;
	  }
	  
	  public BufferedImage  interpolate_image(BufferedImage img) {
		    int width = image.getWidth(this);
		    int height = image.getHeight(this);
		    bufferedImage = new BufferedImage(width, height,
		        BufferedImage.TYPE_INT_RGB);
		    Graphics2D big = bufferedImage.createGraphics();
		    AffineTransform affineTransform = new AffineTransform();
		    big.drawImage(image, affineTransform, this);
		    Kernel kernel = new Kernel(3, 3, SHARP);
		    convolveOp = new ConvolveOp(kernel, ConvolveOp.EDGE_NO_OP, null);
			return img;
		  }
	  
	  public int[][] generate_mask(int width,int height,int idx) {
		  
		  int m[][]=new int[width][height];
		  int phasex,phasey;
		  m=numpyZeros(width, height);
		  phasex = idx % width;
		  phasey =  Math.floorDiv(idx,width)%width;
		  m[phasex][phasey]=1;
		  return m;
	  }
	 
	  
	  public void invariant_denoise(BufferedImage img, int width, int denoiser) {
		  int n_masks;
		  int m[][]=new int[img.getWidth()][img.getHeight()];
		  BufferedImage interp;
		  int output[][]=new int[img.getWidth()][img.getHeight()];
		  
		  n_masks= width*width;
				    
				    interp = interpolate_image(img);
				    
				    output = numpyZeros(img.getWidth(),img.getHeight());
				    
				    for (int i=0;i<n_masks;i++) {
				    	 m = generate_mask(img.getWidth(), img.getHeight(), i);
				    	 //input_image = m*interp + (1 - m)*img
						 //input_image = input_image.astype(img.dtype)
						 //output += m*denoiser(input_image)
				    }
				       
	  }
	  
	public static void main(String[] args) {
		 Frame f = new Convolution();
		    f.setTitle("ConvolveIt");
		    f.setSize(300, 250);
		    f.show();
	}
}