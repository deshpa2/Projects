Project code path:Noise2Self\src\main\java

MAJOR FUNCTIONS USED:

1) medianFilter()

2) Interpolate()

3) donutFilter()

UTILITY FUNCTIONS:

5) saveImage()

6) getPixel()

7) getSinglePixel()


Libraries for Image processing:
1) java.awt
2) javax.imageio
3) javax.swing

Processing:
The noisy Images are taken as input and Image processing is carried out and the corresponding result is saved in the same folder.

Dry run for single input processing:
1) Input image path for code:\\Noise2Self\\src\\main\\java\\Images\\noisy_10.jpg
Note: This image can be found in the Noise2Self\\src\\main\\java\\Images\\noisy_10.jpg in the zip file

2) This input image is passed to a function called "medianFilter()" which is in the Util Class.The "medianFilter()" function reads the Image and converts it into a matrix
of pixels and performs the convolution operation of the entire image at pixel level and return the output image.The logic behind median filter is that it convolves 
around the input image considering 3x3 sets of input pixels, stores and sorts 9 pixels according to their ascending order of intensities and replaces the center pixel
by the median value of the 9 pixel values.

The Output of this operation is stored in the same location "Noise2Self\\src\\main\\java\\Images\Median1" and file name is "Median1.jpg"

3) In a similar fashion input image is passed to the function "Interpolate()" which is in the Util Class.The "Interpolate()" function reads the Image and converts it into 
a matrix of pixels and performs the convolution operation returning an output.The "Interpolate()" function uses the filter operation i.e the preprocessing performed by
the author while training the model for denoising, which is implemented in this code.

The Output of this operation is stored in the same location "Noise2Self\\src\\main\\java\\Images\Interpolated1" and file name is "Interpolated1.jpg"

4)Similarly input is processed using "donutFilter()" function from Util Class.This function is very similar to median filter except it considers 8 pixels data to
  assign the pixel vaue of the center pixel.This filter convolutes on the input using 3x3 convolution filter but the center pixel is set to transparent i.e zero intensity,
  the data from the 8 pixels are sorted and the median value is assigned to the center pixel similar to the median filter operation.
 
The Output of this operation is stored in the same location "Noise2Self\\src\\main\\java\\Images\Donut_Filter1" and file name is "Donut_Filter1.jpg"  

Experiments:
1) The variance of gausian noise is increased to 0.03,0.05 and 0.1 in the clear image and the output of the above operations is stored in the following location:
variance 0.03: \Noise2Self\src\main\java\Images\Analysis\var3
variance 0.05: \Noise2Self\src\main\java\Images\Analysis\var5
variance 0.1:  \Noise2Self\src\main\java\Images\Analysis\var10
The result analysis of the same is described in the report.

2) The ongoing experiments and output on different types of noisy images can be seen in the following location:
\Noise2Self\src\main\java\Images\Experiments

Note: The subfolders in this location have various experimental results including a gausian noise filter which is being further analysed and can be used in part 2
of the project

Note: various coding statements are commented in the main() of the code for ease of access for experiments, also few analysis functions are tried out in the Util class
for the same.

Note:The calling of all functions is written in the main function in the main class at the following path:
Noise2Self\src\main\java\com
